import { useState } from "react";
import axios from "axios";
import beautify from "js-beautify/js";
import "./App.css";

function App() {
  const [count, setCount] = useState(0);
  const [inputText, setInputText] = useState("");
  const [answer, setAnswer] = useState("");
  async function getRequest(e) {
    e.preventDefault();
    const response = await axios.post(
      "http://192.168.251.212:5555/v1/completions",
      {
        model: "/Hard_Disk-2/coe_codestral",
        prompt: inputText,
        max_tokens: 256,
        temperature: 0,
      }
    );
    setAnswer(response.data.choices[0].text);
  }
  return (
    <>
      <form
        onSubmit={(e) => {
          getRequest(e);
        }}
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => {
            setInputText(e.target.value);
            console.log(e.target.value);
          }}
        />
        <button>SUBMIT</button>
      </form>
      {answer.length > 0 ? <code>{beautify(answer)}</code> : "Type something"}
    </>
  );
}

export default App;
